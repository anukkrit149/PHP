<?php
/**
 * Created by PhpStorm.
 * User: Anukkrit
 * Date: 02-07-2019
 * Summary-
 * API Used-
 * Limitations-
 */

require "connection.php";

if (isset($_POST['file-submit'])){

     foreach ($_FILES['file']['name'] as $key=>$val){

         $path="uploads/".$_GET['itemId'];

         if(!is_dir($path))
             mkdir($path);
         $time=time();
         $target=$path."/".$time;
         if (move_uploaded_file($_FILES['file']['tmp_name'][$key],$target)){
              echo "file uploaded";
              $stmt=$pdo->prepare("INSERT INTO itempics(itemid,path) VALUES(?,?) ");
              $res=$stmt->execute([$_GET['itemId'],$target,$_GET['cat']]);
              if ($res)
                  header("Location:index.php?res=1");
              else
                  header("Location:index.php?res=-1");

         }else
             header("Location:index.php?res=-2");
     }
}
?>