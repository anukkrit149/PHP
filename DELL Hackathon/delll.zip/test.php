<?php

include 'assets/elements/header.php';


var_dump($_SESSION);


?>