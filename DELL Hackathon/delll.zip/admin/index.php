<!DOCTYPE html>
<html lang="en">
    <?php include 'elements/header.php'; ?>
<body class="fixed-left">
<!-- Loader -->
<div id="preloader">
    <div id="status">
        <div class="spinner">
            <div class="rect1"></div>
            <div class="rect2"></div>
            <div class="rect3"></div>
            <div class="rect4"></div>
            <div class="rect5"></div>
        </div>
    </div>
</div>
<?php
/**
 * Created by PhpStorm.
 * User: Anukkrit
 * Date: 07-07-2019
 * Summary-
 * API Used-
 * Limitations-
 */
 
include 'dbcontroller.php';
include "connection.php";

// if (!$_SESSION['loggedIN'])
//     header("Location:login.php?res=loginError");
    
$db=new DBController();
$db->connectDB();
$count=$db->runQuery("SELECT COUNT(*) FROM `item`");
$last=$db->runQuery("SELECT MAX(itID) FROM `item`");   
    
    
    
?>
<!-- Begin page -->
<div id="wrapper">
    <!-- ========== Left Sidebar Start ========== -->
    <?php include 'elements/sidebar.php'; ?>
    <!-- Left Sidebar End -->
    <!-- Start right Content here -->
    <div class="content-page">
        <!-- Start content -->
        <div class="content">
            <!-- Top Bar Start -->
             <?php include 'elements/topbar.php'; ?>
            <!-- Top Bar End -->
            <div class="page-content-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title-box">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <h4 class="page-title m-0">Dashboard</h4>
                                    </div>
                                    <!--<div class="col-md-4">-->
                                        <!--<div class="float-right d-none d-md-block">-->
                                            <!--<div class="dropdown">-->
                                                <!--<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">-->
                                                    <!--<i class="ti-settings mr-1"></i> Settings-->
                                                <!--</button>-->
                                                <!--<div class="dropdown-menu dropdown-menu-right dropdown-menu-animated">-->
                                                    <!--<a class="dropdown-item" href="#">Action</a>-->
                                                    <!--<a class="dropdown-item" href="#">Another action</a>-->
                                                    <!--<a class="dropdown-item" href="#">Something else here</a>-->
                                                    <!--<div class="dropdown-divider"></div>-->
                                                    <!--<a class="dropdown-item" href="#">Separated link</a>-->
                                                <!--</div>-->
                                            <!--</div>-->
                                        <!--</div>-->
                                    <!--</div>-->
                                    <!-- end col -->
                                </div>
                                <!-- end row -->
                            </div>
                            <!-- end page-title-box -->
                        </div>
                    </div>
                    <!-- end page title -->
                     <div class="row">
                        <div class="col-xl-12 col-md-12">
                            <div class="card bg-primary mini-stat text-white">
                                <div class="p-3 mini-stat-desc">
                                    <div class="clearfix">
                                        <h6 class="text-uppercase mt-0 float-left text-white-50">Items Uploaded</h6>
                                        <h4 class="mb-3 mt-0 float-right"><?php echo $count[0]['COUNT(*)'];?></h4>
                                    </div>
                                </div>
                                <div class="p-3">
                                    <div class="float-right">
                                        <a href="#" class="text-white-50">
                                            <i class="mdi mdi-cube-outline h5"></i>
                                        </a>
                                    </div>
                                    <p class="font-14 m-0">Last ItemID: <?php echo $last[0]['MAX(itID)'];?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <div class="row">
                       
                    </div>
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-b-30">
                                <div class="card-body" id="crd">
                                    <table id="items" class="display" style="width:100%">
        <thead>
            <tr>
                
                <?php
                $q = $pdo->prepare("DESCRIBE item");
                $q->execute();
                $table_fields = $q->fetchAll(PDO::FETCH_COLUMN);
                foreach($table_fields as $KEY=>$VAL)
                  echo "<td>".$VAL."</td>";
                echo "<td>Featured pdts</td>";
                ?>
            </tr>
        </thead>
        <tbody>
            
               <?php
                $q = $pdo->prepare("Select * from item");
                $q->execute();
               $data = $q->fetchAll(PDO::FETCH_ASSOC);
               foreach($data as $row) {
                   echo "<tr>";
          foreach($row as $cell=>$val){
              echo "<td>".$val."</td>";
          }
          echo "<td><a href='featureSet.php?pid=".$row['itID']."'>Set/Unset</a></td>";
          echo "</tr>";
}
                ?>
            
         

            
            
        </tbody>
    </table>
                                    
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                        
                      
                    <!-- end row -->
                </div>
                <!-- container fluid -->
            </div>
            <!-- Page content Wrapper -->
        </div>
        <!-- content -->
        <footer class="footer">© 2019 wiseKreator
            <span class="d-none d-md-inline-block">- Crafted with<i class="mdi mdi-heart text-danger"></i> by Anukkrit.</span>
        </footer>
    </div>
    <!-- End Right content here -->
</div>
<!-- END wrapper -->
<!-- jQuery  -->
 <script>
    
    // $.noConflict();
    
    
    $( document ).ready(function() {
        // jQuery('#crd').css("overflow-y", "scroll");
   $('#items').DataTable({
       
      "scrollX": true,
      "scrollY": 300,
      scrollCollapse: true,
        // paging: false,
    } ).column(5).visible(false);
    });
</script>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/modernizr.min.js"></script>
<script src="assets/js/detect.js"></script>
<script src="assets/js/fastclick.js"></script>
<script src="assets/js/jquery.slimscroll.js"></script>
<script src="assets/js/jquery.blockUI.js"></script>
<script src="assets/js/waves.js"></script>
<script src="assets/js/jquery.nicescroll.js"></script>
<script src="assets/js/jquery.scrollTo.min.js"></script>
<!--Morris Chart-->
<script src="../plugins/morris/morris.min.js"></script>
<script src="../plugins/raphael/raphael.min.js"></script>
<!-- dashboard js -->
<script src="assets/pages/dashboard.int.js"></script>
<!-- App js -->
<script src="assets/js/app.js"></script>
</body>
</html>