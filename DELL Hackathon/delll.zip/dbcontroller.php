<?php
/**
 * Created by PhpStorm.
 * User: Anukkrit
 * Date: 06-07-2019
 * Summary-
 * API Used-
 * Limitations-
 */



class DBController {
    private $host = "localhost";
    private $user = "wiseltxh_dell";
    private $password = "DELL1234";
    private $database = "wiseltxh_dell";
    private $conn;

    function __construct() {
        $this->conn = $this->connectDB();
    }

    function connectDB() {
        $conn = mysqli_connect($this->host,$this->user,$this->password,$this->database);
        return $conn;
    }

    function runQuery($query) {
        $result = mysqli_query($this->conn,$query);
        while($row=mysqli_fetch_assoc($result)) {
            $resultset[] = $row;
        }
        if(!empty($resultset))
            return $resultset;
    }

    function numRows($query) {
        $result  = mysqli_query($this->conn,$query);
        $rowcount = mysqli_num_rows($result);
        return $rowcount;
    }
}
?>