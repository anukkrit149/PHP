<!doctype html>
<html class="no-js" lang="zxx">


<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DELL | Cart</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <!-- CSS
	============================================ -->
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,900" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Pe-icon-7-stroke CSS -->
    <link rel="stylesheet" href="assets/css/vendor/pe-icon-7-stroke.css">
    <!-- Font-awesome CSS -->
    <link rel="stylesheet" href="assets/css/vendor/font-awesome.min.css">
    <!-- Slick slider css -->
    <link rel="stylesheet" href="assets/css/plugins/slick.min.css">
    <!-- animate css -->
    <link rel="stylesheet" href="assets/css/plugins/animate.css">
    <!-- Nice Select css -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.css">
    <!-- jquery UI css -->
    <link rel="stylesheet" href="assets/css/plugins/jqueryui.min.css">
    <!-- main style css -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>
    <?php 	include 'assets/elements/header.php';	?>


    <main>
        <!-- breadcrumb area start -->
        <div class="breadcrumb-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap">
                            <nav aria-label="breadcrumb">
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home"></i></a></li>
                                    <li class="breadcrumb-item"><a href="shop.php">shop</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">cart</li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb area end -->

        <!-- cart main wrapper start -->
        <div class="cart-main-wrapper section-padding">
            <div class="container">
                <div class="section-bg-color">
                    <div class="row">
                        <div class="col-lg-12">
                            <!-- Cart Table Area -->
                            <div class="cart-table table-responsive">
                                <table class="table table-bordered">
                                <thead>
                                <tr>
                                    <th class="pro-thumbnail">Thumbnail</th>
                                    <th class="pro-title">Product</th>
                                    <th class="pro-price">Quantity</th>
                                    <th class="pro-quantity">Price</th>
                                    <th class="pro-remove">CheckList</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                /**
                                 * Created by PhpStorm.
                                 * User: Anukkrit
                                 * Date: 24-07-2019
                                 * Summary-
                                 * API Used-
                                 * Limitations-
                                 */
                                 $d=0;
                                foreach ($_SESSION["cart_item"] as $key => $value)
                                {
                                    $d+=1;
                                    if (!empty($value['name'])){
                                    // $pic_rows=$db->runQuery('SELECT * FROM itempic WHERE itID='.$value['id']);
                                    // var_dump($pic_rows);
                                    // exit();
                                    echo "<tr class='item'>
                                    <td class=\"pro-thumbnail\"><a href=product-details.php?pid=".$value['id']."><img class=\"img-fluid\" src='".$value['img']."' alt=\"Product\" /></a></td>
                                    <td class=\"pro-title\"><a href=product-details.php?pid=".$value['id'].">".$value['name']."</a></td>
                                    <td class=\"pro-quantity\">
                                        ".$value['quantity']."
                                    </td>
                                    <td class=\"pro-price\" id='p".$d."'><span>".$value['price']."</span></td>
                                    <td class=\"pro-price\"><input type='checkbox' class='form-check-input' id='c".$d."'></td>
                                    
                                    
                                </tr>";}
                                

                                }


                                ?>
                                </tbody>
                            </table>
                            </div>
                            <!-- Cart Update Option -->
                            <div class="cart-update-option d-block d-md-flex justify-content-between">
                                <!--<div class="apply-coupon-wrapper">-->
                                <!--    <form action="#" method="post" class=" d-block d-md-flex">-->
                                <!--        <input type="text" placeholder="Enter Your Coupon Code" required />-->
                                <!--        <button class="btn btn-sqr">Apply Coupon</button>-->
                                <!--    </form>-->
                                <!--</div>-->
                                <div class="cart-update">
                                    <a href="#" class="btn btn-sqr">Update Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-5 ml-auto">
                            <!-- Cart Calculation Area -->
                            <div class="cart-calculator-wrapper">
                                <div class="cart-calculate-items">
                                    <h6>Cart Totals</h6>
                                    <div class="table-responsive">
                                        <table class="table">
                                            <!--<tr>-->
                                            <!--    <td>Sub Total</td>-->
                                            <!--    <td>$230</td>-->
                                            <!--</tr>-->
                                            <!--<tr>-->
                                            <!--    <td>Shipping</td>-->
                                            <!--    <td>$70</td>-->
                                            <!--</tr>-->
                                            <tr class="total">
                                                <td>Total</td>
                                                <td class="total-amount" id="#amt"><?php echo $_SESSION["totalprice"];?></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                                <a href="checkout.php" class="btn btn-sqr d-block">Proceed Checkout</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- cart main wrapper end -->
    </main>

    <!-- Scroll to top start -->
    <div class="scroll-top not-visible">
        <i class="fa fa-angle-up"></i>
    </div>
    <!-- Scroll to Top End -->

<?php 	include 'assets/elements/footer.php';	?> 
<script>
$(document).ready(function() {
    //set initial state.
    // $('#Check1').val(this.checked);
    var sum=0;
    // $('tr.item').each(function(){
        $('#c2').change(function() {
        if(this.checked) {
            sum+=parseInt($('#p2').text());
            $('#amt').text(sum);
            alert('Total Price-'+sum);
        }else if (sum-parseInt($('#p2').text())>=0){
            
            sum-=parseInt($('#p2').text());
            alert('Total Price-'+sum);
        }
        
        
    });
    
    
    $('#c3').change(function() {
        if(this.checked) {
            sum+=parseInt($('#p3').text());
            alert('Total Price-'+sum);
        }else if (sum-parseInt($('#p3').text())>=0){
            
            sum-=parseInt($('#p3').text());
            alert('Total Price-'+sum);
        }
        
    });

//   });
   console.log(sum);
});
    </script>
    
    

    <!-- JS
============================================ -->

    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.3.1.min.js"></script>
    <!-- Popper JS -->
    <script src="assets/js/vendor/popper.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.min.js"></script>
    <!-- slick Slider JS -->
    <script src="assets/js/plugins/slick.min.js"></script>
    <!-- Countdown JS -->
    <script src="assets/js/plugins/countdown.min.js"></script>
    <!-- Nice Select JS -->
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- jquery UI JS -->
    <script src="assets/js/plugins/jqueryui.min.js"></script>
    <!-- Image zoom JS -->
    <script src="assets/js/plugins/image-zoom.min.js"></script>
    <!-- Imagesloaded JS -->
    <script src="assets/js/plugins/imagesloaded.pkgd.min.js"></script>
    <!-- Instagram feed JS -->
    <script src="assets/js/plugins/instagramfeed.min.js"></script>
    <!-- mailchimp active js -->
    <script src="assets/js/plugins/ajaxchimp.js"></script>
    <!-- contact form dynamic js -->
    <script src="assets/js/plugins/ajax-mail.js"></script>
    <!-- google map api -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCfmCVTjRI007pC1Yk2o2d_EhgkjTsFVN8"></script>
    <!-- google map active js -->
    <script src="assets/js/plugins/google-map.js"></script>
    <!-- Main JS -->
    <script src="assets/js/main.js"></script>
</body>


</html>