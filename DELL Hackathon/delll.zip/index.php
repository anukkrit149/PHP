<?php
/**
 * Created by PhpStorm.
 * User: Anukkrit
 * Date: 07-07-2019
 * Summary-
 * API Used-
 * Limitations-
 */



// session_start();
include "connection.php";
include "dbcontroller.php";

$db= new DBController();

$db->connectDB();
$cat=$db->runQuery("SELECT * FROM cat");

// var_dump($db);
// exit();
?>


<!doctype html>
<html class="no-js" lang="en">



<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DELL | Products</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <!-- CSS
	============================================ -->
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,900" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Pe-icon-7-stroke CSS -->
    <link rel="stylesheet" href="assets/css/vendor/pe-icon-7-stroke.css">
    <!-- Font-awesome CSS -->
    <link rel="stylesheet" href="assets/css/vendor/font-awesome.min.css">
    <!-- Slick slider css -->
    <link rel="stylesheet" href="assets/css/plugins/slick.min.css">
    <!-- animate css -->
    <link rel="stylesheet" href="assets/css/plugins/animate.css">
    <!-- Nice Select css -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.css">
    <!-- jquery UI css -->
    <link rel="stylesheet" href="assets/css/plugins/jqueryui.min.css">
    <!-- main style css -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>
    <!-- Start Header Area -->
    <?php 	include 'assets/elements/header.php';	?>



    <main>
        <!-- hero slider area start -->
        <section class="slider-area">
            <div class="hero-slider-active slick-arrow-style slick-arrow-style_hero slick-dot-style">
                <!-- single slider item start -->
                <div class="hero-single-slide hero-overlay">
                    <div class="hero-slider-item bg-img" data-bg="https://i.dell.com/das/dih.ashx/1800w/sites/csimages/Banner_Imagery/en/in-bsd-ubh-advisor.jpg">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="hero-slider-content slide-1">
                                        <h2 class="slide-title">Laptop<span>Collection</span></h2>
                                        <h4 class="slide-desc">from $699</h4>
                                        <a href="shop.php" class="btn btn-hero">Read More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single slider item end -->

                <!-- single slider item start -->
                <div class="hero-single-slide hero-overlay">
                    <div class="hero-slider-item bg-img" data-bg="https://i.dell.com/das/dih.ashx/1800w/sites/imagecontent/app-merchandizing/responsive/Shop/Browse/PublishingImages/2800-x-944_2.jpg">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="hero-slider-content slide-2">
                                        <h2 class="slide-title" style="color: white;">Server <span>Collection</span></h2>
                                        <h4 class="slide-desc" style="color: white;">test </h4>
                                        <a href="shop.php" class="btn btn-hero">Read More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single slider item start -->

                <!-- single slider item start -->
                <div class="hero-single-slide hero-overlay">
                    <div class="hero-slider-item bg-img" data-bg="https://i.dell.com/das/dih.ashx/1800w/sites/csimages/Banner_Imagery/en/in-dhs-uber-hp-wasp-silver.jpg">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="hero-slider-content slide-3">
                                        <h2 class="slide-title">Desktop<span>Collection</span></h2>
                                        <h4 class="slide-desc">test</h4>
                                        <a href="shop.php" class="btn btn-hero">Read More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single slider item start -->
            </div>
        </section>
        <!-- hero slider area end -->

        <!-- about us area start -->
        <section class="about-us section-padding">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-5">
                        <div class="about-thumb">
                            <img src="https://i.dell.com/sites/imagecontent/app-merchandizing/responsive/HomePage/en/PublishingImages/570-x-283.png" alt="about thumb">
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="about-content">
                            <h2 class="about-title">About Us</h2>
                            <h5 class="about-sub-title">
                              PARAGRAPH
                            </h5>
                            <p>sadad</p>
                            <p>asda</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- about us area end -->

        
        <!-- product banner statistics area start -->
        <section class="product-banner-statistics section-padding">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="section-title text-center">
                            <h2 class="title">Categories</h2>
                            <p class="sub-title">Choose your Category</p>
                        </div>
                        <div class="product-banner-carousel slick-row-10">
                            <?php 
                        $i=0;
                        while(true){
    if(empty($cat[$i]))
        break;
    // $pic_rows=$db->runQuery('SELECT * FROM itempic WHERE itID='.$category[$i]['itID']);
    echo "<div class=\"banner-slide-item\">
                                <figure class=\"banner-statistics\">
                                    <a href=shop.php?catid=".$cat[$i]['id'].">
                                        <img src=".$cat[$i]['img']." alt=\"product banner\">
                                    </a>
                                    <div class=\"banner-content banner-content_style2\">
                                        <h5 class=\"banner-text3\">".$cat[$i]['name']."</h5>
                                    </div>
                                </figure>
                            </div>";
    $i++;

}
                        
                        ?>
                            <!-- banner single slide start -->
                            <!--<div class="banner-slide-item">-->
                            <!--    <figure class="banner-statistics">-->
                            <!--        <a href="#">-->
                            <!--            <img src="assets/img/banner/img1-middle.jpg" alt="product banner">-->
                            <!--        </a>-->
                            <!--        <div class="banner-content banner-content_style2">-->
                            <!--            <h5 class="banner-text3"><a href="#">BRACELATES</a></h5>-->
                            <!--        </div>-->
                            <!--    </figure>-->
                            <!--</div>-->
                            <!-- banner single slide start -->
                            <!-- banner single slide start -->
                            <!--<div class="banner-slide-item">-->
                            <!--    <figure class="banner-statistics">-->
                            <!--        <a href="#">-->
                            <!--            <img src="assets/img/banner/img2-middle.jpg" alt="product banner">-->
                            <!--        </a>-->
                            <!--        <div class="banner-content banner-content_style2">-->
                            <!--            <h5 class="banner-text3"><a href="#">EARRINGS</a></h5>-->
                            <!--        </div>-->
                            <!--    </figure>-->
                            <!--</div>-->
                            <!-- banner single slide start -->
                            <!-- banner single slide start -->
                            <!--<div class="banner-slide-item">-->
                            <!--    <figure class="banner-statistics">-->
                            <!--        <a href="#">-->
                            <!--            <img src="assets/img/banner/img3-middle.jpg" alt="product banner">-->
                            <!--        </a>-->
                            <!--        <div class="banner-content banner-content_style2">-->
                            <!--            <h5 class="banner-text3"><a href="#">NECJLACES</a></h5>-->
                            <!--        </div>-->
                            <!--    </figure>-->
                            <!--</div>-->
                            <!-- banner single slide start -->
                            <!-- banner single slide start -->
                            <!--<div class="banner-slide-item">-->
                            <!--    <figure class="banner-statistics">-->
                            <!--        <a href="#">-->
                            <!--            <img src="assets/img/banner/img4-middle.jpg" alt="product banner">-->
                            <!--        </a>-->
                            <!--        <div class="banner-content banner-content_style2">-->
                            <!--            <h5 class="banner-text3"><a href="#">RINGS</a></h5>-->
                            <!--        </div>-->
                            <!--    </figure>-->
                            <!--</div>-->
                            <!-- banner single slide start -->
                            <!-- banner single slide start -->
                            <!--<div class="banner-slide-item">-->
                            <!--    <figure class="banner-statistics">-->
                            <!--        <a href="#">-->
                            <!--            <img src="assets/img/banner/img5-middle.jpg" alt="product banner">-->
                            <!--        </a>-->
                            <!--        <div class="banner-content banner-content_style2">-->
                            <!--            <h5 class="banner-text3"><a href="#">PEARLS</a></h5>-->
                            <!--        </div>-->
                            <!--    </figure>-->
                            <!--</div>-->
                            <!-- banner single slide start -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- product banner statistics area end -->

        
    </main>

    <!-- Scroll to top start -->
    <div class="scroll-top not-visible">
        <i class="fa fa-angle-up"></i>
    </div>
    <!-- Scroll to Top End -->

<?php 	include 'assets/elements/footer.php';	?> 

    <!-- Quick view modal start -->
    <div class="modal" id="quick_view">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <!-- product details inner end -->
                    <div class="product-details-inner">
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="product-large-slider">
                                    <div class="pro-large-img img-zoom">
                                        <img src="assets/img/product/product-details-img1.jpg" alt="product-details" />
                                    </div>
                                    <div class="pro-large-img img-zoom">
                                        <img src="assets/img/product/product-details-img2.jpg" alt="product-details" />
                                    </div>
                                    <div class="pro-large-img img-zoom">
                                        <img src="assets/img/product/product-details-img3.jpg" alt="product-details" />
                                    </div>
                                    <div class="pro-large-img img-zoom">
                                        <img src="assets/img/product/product-details-img4.jpg" alt="product-details" />
                                    </div>
                                    <div class="pro-large-img img-zoom">
                                        <img src="assets/img/product/product-details-img5.jpg" alt="product-details" />
                                    </div>
                                </div>
                                <div class="pro-nav slick-row-10 slick-arrow-style">
                                    <div class="pro-nav-thumb">
                                        <img src="assets/img/product/product-details-img1.jpg" alt="product-details" />
                                    </div>
                                    <div class="pro-nav-thumb">
                                        <img src="assets/img/product/product-details-img2.jpg" alt="product-details" />
                                    </div>
                                    <div class="pro-nav-thumb">
                                        <img src="assets/img/product/product-details-img3.jpg" alt="product-details" />
                                    </div>
                                    <div class="pro-nav-thumb">
                                        <img src="assets/img/product/product-details-img4.jpg" alt="product-details" />
                                    </div>
                                    <div class="pro-nav-thumb">
                                        <img src="assets/img/product/product-details-img5.jpg" alt="product-details" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-7">
                                <div class="product-details-des">
                                    <div class="manufacturer-name">
                                        <a href="product-details.php">HasTech</a>
                                    </div>
                                    <h3 class="product-name">Handmade Golden Necklace</h3>
                                    <div class="ratings d-flex">
                                        <span><i class="fa fa-star-o"></i></span>
                                        <span><i class="fa fa-star-o"></i></span>
                                        <span><i class="fa fa-star-o"></i></span>
                                        <span><i class="fa fa-star-o"></i></span>
                                        <span><i class="fa fa-star-o"></i></span>
                                        <div class="pro-review">
                                            <span>1 Reviews</span>
                                        </div>
                                    </div>
                                    <div class="price-box">
                                        <span class="price-regular">$70.00</span>
                                        <span class="price-old"><del>$90.00</del></span>
                                    </div>
                                    <h5 class="offer-text"><strong>Hurry up</strong>! offer ends in:</h5>
                                    <div class="product-countdown" data-countdown="2019/09/20"></div>
                                    <div class="availability">
                                        <i class="fa fa-check-circle"></i>
                                        <span>200 in stock</span>
                                    </div>
                                    <p class="pro-desc">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy
                                        eirmod tempor invidunt ut labore et dolore magna.</p>
                                    <div class="quantity-cart-box d-flex align-items-center">
                                        <h6 class="option-title">qty:</h6>
                                        <div class="quantity">
                                            <div class="pro-qty"><input type="text" value="1"></div>
                                        </div>
                                        <div class="action_link">
                                            <a class="btn btn-cart2" href="#">Add to cart</a>
                                        </div>
                                    </div>
                                    <div class="useful-links">
                                        <a href="#" data-toggle="tooltip" title="Compare"><i
                                            class="pe-7s-refresh-2"></i>compare</a>
                                        <a href="#" data-toggle="tooltip" title="Wishlist"><i
                                            class="pe-7s-like"></i>wishlist</a>
                                    </div>
                                    <div class="like-icon">
                                        <a class="facebook" href="#"><i class="fa fa-facebook"></i>like</a>
                                        <a class="twitter" href="#"><i class="fa fa-twitter"></i>tweet</a>
                                        <a class="pinterest" href="#"><i class="fa fa-pinterest"></i>save</a>
                                        <a class="google" href="#"><i class="fa fa-google-plus"></i>share</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- product details inner end -->
                </div>
            </div>
        </div>
    </div>
    <!-- Quick view modal end -->

    <!-- offcanvas mini cart start -->
    <!--<div class="offcanvas-minicart-wrapper">-->
    <!--    <div class="minicart-inner">-->
    <!--        <div class="offcanvas-overlay"></div>-->
    <!--        <div class="minicart-inner-content">-->
    <!--            <div class="minicart-close">-->
    <!--                <i class="pe-7s-close"></i>-->
    <!--            </div>-->
    <!--            <div class="minicart-content-box">-->
    <!--                <div class="minicart-item-wrapper">-->
    <!--                    <ul>-->
    <!--                        <li class="minicart-item">-->
    <!--                            <div class="minicart-thumb">-->
    <!--                                <a href="product-details.php">-->
    <!--                                    <img src="assets/img/cart/cart-1.jpg" alt="product">-->
    <!--                                </a>-->
    <!--                            </div>-->
    <!--                            <div class="minicart-content">-->
    <!--                                <h3 class="product-name">-->
    <!--                                    <a href="product-details.php">Dozen White Botanical Linen Dinner Napkins</a>-->
    <!--                                </h3>-->
    <!--                                <p>-->
    <!--                                    <span class="cart-quantity">1 <strong>&times;</strong></span>-->
    <!--                                    <span class="cart-price">$100.00</span>-->
    <!--                                </p>-->
    <!--                            </div>-->
    <!--                            <button class="minicart-remove"><i class="pe-7s-close"></i></button>-->
    <!--                        </li>-->
    <!--                        <li class="minicart-item">-->
    <!--                            <div class="minicart-thumb">-->
    <!--                                <a href="product-details.php">-->
    <!--                                    <img src="assets/img/cart/cart-2.jpg" alt="product">-->
    <!--                                </a>-->
    <!--                            </div>-->
    <!--                            <div class="minicart-content">-->
    <!--                                <h3 class="product-name">-->
    <!--                                    <a href="product-details.php">Dozen White Botanical Linen Dinner Napkins</a>-->
    <!--                                </h3>-->
    <!--                                <p>-->
    <!--                                    <span class="cart-quantity">1 <strong>&times;</strong></span>-->
    <!--                                    <span class="cart-price">$80.00</span>-->
    <!--                                </p>-->
    <!--                            </div>-->
    <!--                            <button class="minicart-remove"><i class="pe-7s-close"></i></button>-->
    <!--                        </li>-->
    <!--                    </ul>-->
    <!--                </div>-->

    <!--                <div class="minicart-pricing-box">-->
    <!--                    <ul>-->
    <!--                        <li>-->
    <!--                            <span>sub-total</span>-->
    <!--                            <span><strong>$300.00</strong></span>-->
    <!--                        </li>-->
    <!--                        <li>-->
    <!--                            <span>Eco Tax (-2.00)</span>-->
    <!--                            <span><strong>$10.00</strong></span>-->
    <!--                        </li>-->
    <!--                        <li>-->
    <!--                            <span>VAT (20%)</span>-->
    <!--                            <span><strong>$60.00</strong></span>-->
    <!--                        </li>-->
    <!--                        <li class="total">-->
    <!--                            <span>total</span>-->
    <!--                            <span><strong>$370.00</strong></span>-->
    <!--                        </li>-->
    <!--                    </ul>-->
    <!--                </div>-->

    <!--                <div class="minicart-button">-->
    <!--                    <a href="cart.php"><i class="fa fa-shopping-cart"></i> View Cart</a>-->
    <!--                    <a href="cart.php"><i class="fa fa-share"></i> Checkout</a>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!-- offcanvas mini cart end -->

    <!-- JS
============================================ -->

    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.3.1.min.js"></script>
    <!-- Popper JS -->
    <script src="assets/js/vendor/popper.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.min.js"></script>
    <!-- slick Slider JS -->
    <script src="assets/js/plugins/slick.min.js"></script>
    <!-- Countdown JS -->
    <script src="assets/js/plugins/countdown.min.js"></script>
    <!-- Nice Select JS -->
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- jquery UI JS -->
    <script src="assets/js/plugins/jqueryui.min.js"></script>
    <!-- Image zoom JS -->
    <script src="assets/js/plugins/image-zoom.min.js"></script>
    <!-- Imagesloaded JS -->
    <script src="assets/js/plugins/imagesloaded.pkgd.min.js"></script>
    <!-- Instagram feed JS -->
    <script src="assets/js/plugins/instagramfeed.min.js"></script>
    <!-- mailchimp active js -->
    <script src="assets/js/plugins/ajaxchimp.js"></script>
    <!-- contact form dynamic js -->
    <script src="assets/js/plugins/ajax-mail.js"></script>
    <!-- google map api -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCfmCVTjRI007pC1Yk2o2d_EhgkjTsFVN8"></script>
    <!-- google map active js -->
    <script src="assets/js/plugins/google-map.js"></script>
    <!-- Main JS -->
    <script src="assets/js/main.js"></script>
</body>


