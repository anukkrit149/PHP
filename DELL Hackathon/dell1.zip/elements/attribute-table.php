

<div class="bs-example container" data-example-id="striped-table">
  <table class="table table-striped table-bordered table-hover">
    <thead>
      <tr>
        <th>Attribute</th>
        <th>Value</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row">1</th>
        <td>Mark</td>
      </tr>
      <tr>
        <th scope="row">2</th>
        <td>Jacob</td>
      </tr>
      <tr>
        <th scope="row">3</th>
        <td>Larry</td>
      </tr>
    </tbody>
    <tfoot>
    <tr class="note"><th>Notes Here</th><td colspan=3><a href="#">Share this Product</a></td></tr>
    </tfoot>
  </table>
</div>

<style>
    .note{
  color: #777;
  font-size: 0.85em;
}
</style>