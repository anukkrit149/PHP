 <div class="related negative-grid">
                    
                    
                        <div class="c_header">
                            <div class="grid_10">
                                <h2>Related Products</h2>
                            </div><!-- .grid_10 -->

                            <div class="grid_2">
                                <a id="next_c1" class="next arows" href="#"><span>Next</span></a>
                                <a id="prev_c1" class="prev arows" href="#"><span>Prev</span></a>
                            </div><!-- .grid_2 -->
                        </div><!-- .c_header -->
                        

                        <div class="related_list">
                            <ul id="listing" class="products">
                                
                                <?php
                   $i=4;
                   while($i)
                   {
                       echo "<li>
                       <article class='grid_3 article'>
                        <div class='prev'>
                            <a href='product_page.php'><img src='img/content/product1.png' alt='Product 1' title=''></a>
                        </div><!-- .prev -->
                        
                        <h3 class='title'>DEMO Emerald Cut<br> DEMO Emerald Ring</h3>
                        <div class='cart'>
                            <div class='price'>
                                <div class='vert'>
                                    DESC
                                    <div class='price_old'></div>
                                </div>
                            </div>".
                            // <a href='#' class='compare'></a>
                            // <a href='#' class='wishlist'></a>
                            "<a href='#' class='bay'><img src='img/bg_cart.png' alt='Buy' title=''></a>
                        </div><!-- .cart -->
                    </article><!-- .grid_3.article -->
                    </li>";
                       
                      $i-=1; 
                   }
                    ?>
                                
                                
                                
                            </ul><!-- #listing -->
                         </div><!-- .brands_list -->
                </div><!-- .related -->