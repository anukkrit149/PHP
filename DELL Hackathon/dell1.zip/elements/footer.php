<!-- footer area start -->
    <footer class="footer-widget-area">
        
        <div class="footer-bottom" >
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <style>
                    .boxescon{border-radius: 25px;
  background: #c29958;
      margin:10px;
                        
                    }
                    
                    @media only screen and (max-width: 600px){
                        .boxescon{
                            border-radius: 25px;
                            background: #c29958;
                            margin:10px;
                            display:block;
                        
                    }
                        
                        
                        
                    }
                    
                    
                </style>
                        <div class="contdiv">
                            <h6>Contact Us:</h6>
                         <a href="https://maps.app.goo.gl/vi5U6UcLvjE14Vp59"> <h6 style="
    margin-bottom: 10px;
">Address:  41, Patharwala building, Shop No. 13, First floor, Vithalwadi, Zaveri Bazaar, Mumbai,
                Maharashtra-400002</h6> </a>
                
<h5>
    <a href="#" id="wht" class="boxescon" style="color: #FFFFFF;">&nbsp &nbsp
    <i class="fa fa-whatsapp" style="color: #FFFFFF"></i>
    <span> 093217 83031 </span>&nbsp &nbsp
    </a>
    <a href="tel:02249243132"  class="boxescon" style="color: #FFFFFF;">&nbsp &nbsp
    <i class="fa fa-phone " style="color: #FFFFFF"> </i>
    <span>  022 49243132</span> &nbsp &nbsp
    </a>
    <a href="tel:02261832158"  class="boxescon" style="color: #FFFFFF;">&nbsp &nbsp 
    <i class="fa fa-phone" style="color: #FFFFFF"></i>
    <span>022 61832158 </span>&nbsp &nbsp</a>
</h5>
                    
                        
                        
                        </div>
                        <div class="copyright-text text-center" style="
    margin-top: 10px;
">
                            <p>Powered By <a href="https://wisekreator.com/">wiseKreator</a>© 2019</p>
                            <!--<div class="like-icon">-->
                            <!--            <a class="facebook" href="#"><i class="fa fa-facebook"></i>like</a>-->
                            <!--            <a class="twitter" href="#"><i class="fa fa-twitter"></i>tweet</a>-->
                            <!--            <a class="pinterest" href="#"><i class="fa fa-pinterest"></i>save</a>-->
                            <!--            <a class="google" href="#"><i class="fa fa-google-plus"></i>share</a>-->
                            <!--        </div>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer area end -->
    <script>
    $(document).ready(
    function(){
         $('#wht').on('click',function(){
           
           var Url=" https://api.whatsapp.com/send?phone=919321783031&text="+encodeURI('Hey,I want to enquire');
          window.location.href = Url;
        });
        
        
        
    });
    </script>
    

    <!-- JS============================================ -->

    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.3.1.min.js"></script>
    <!-- Popper JS -->
    <script src="assets/js/vendor/popper.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.min.js"></script>
    <!-- slick Slider JS -->
    <script src="assets/js/plugins/slick.min.js"></script>
    <!-- Countdown JS -->
    <script src="assets/js/plugins/countdown.min.js"></script>
    <!-- Nice Select JS -->
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- jquery UI JS -->
    <script src="assets/js/plugins/jqueryui.min.js"></script>
    <!-- Image zoom JS -->
    <script src="assets/js/plugins/image-zoom.min.js"></script>
    <!-- Imagesloaded JS -->
    <script src="assets/js/plugins/imagesloaded.pkgd.min.js"></script>
    <!-- Instagram feed JS -->
    <script src="assets/js/plugins/instagramfeed.min.js"></script>
    <!-- mailchimp active js -->
    <script src="assets/js/plugins/ajaxchimp.js"></script>
    <!-- contact form dynamic js -->
    <script src="assets/js/plugins/ajax-mail.js"></script>
    <!-- google map api -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCfmCVTjRI007pC1Yk2o2d_EhgkjTsFVN8"></script>
    <!-- google map active js -->
    <script src="assets/js/plugins/google-map.js"></script>
    <!-- Main JS -->
    <script src="assets/js/main.js"></script>