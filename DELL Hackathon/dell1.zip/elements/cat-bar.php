<div class="breadcrumbs">
        <div class="container_12">
            <div class="grid_12">
                 <a href="index.html">Home</a><span></span><a href="#">Category</a><span></span><span class="current">This page</span>
            </div><!-- .grid_12 -->
        </div><!-- .container_12 -->
    </div><!-- .breadcrumbs -->