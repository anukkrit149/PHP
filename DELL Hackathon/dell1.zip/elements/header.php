<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>VimalSons Jewel</title>
    <meta name="keywords" content="antique piece online,vintage products online,antique decorative items online india,antique items buyer,antique items list,antique showpiece,antique brass items for sale in india,vintage decor,antique items for sale in kerala,pepperfry,antique wall clocks,amazon home decor,vintage home decor,antique piece meaning,old antique items for sale,antique home decor ideas,cheap vintage items,vintage products wholesale,antique showpiece for living room,collectibles india online,old antique piece,antique things shop near me,vintage health products,antiques for sale on ebay,cheap antiques for sale,best online antique stores,sell antiques for cash,antique decorative,antiques collectibles price guide,where to buy antique furniture,online antique furniture store,collectibles ebay,buy antivirus online india,vintage items for sale online india,collectables online india,bonanza antiques,sonrisa vintage furniture"
    <meta name="robots" content="noindex, follow">
    <meta name="description" content="Vimalsons Jewel , a leading establishment in Mumbai in the category of corporate Gift Manufacturers, has its roots in the jewelry industry dating back over 20 years.">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/png" href="assets/img/logo/logo.png">

    <!-- CSS
	============================================ -->
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,900" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Pe-icon-7-stroke CSS -->
    <link rel="stylesheet" href="assets/css/vendor/pe-icon-7-stroke.css">
    <!-- Font-awesome CSS -->
    <link rel="stylesheet" href="assets/css/vendor/font-awesome.min.css">
    <!-- Slick slider css -->
    <link rel="stylesheet" href="assets/css/plugins/slick.min.css">
    <!-- animate css -->
    <link rel="stylesheet" href="assets/css/plugins/animate.css">
    <!-- Nice Select css -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.css">
    <!-- jquery UI css -->
    <link rel="stylesheet" href="assets/css/plugins/jqueryui.min.css">
    <!-- main style css -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Live Search Styles -->
    <link rel="stylesheet" href="css/fontello.css">
    <link rel="stylesheet" href="css/animation.css">
    <!--[if IE 7]>
    <link rel="stylesheet" href="css/fontello-ie7.css">
    <![endif]-->
    <link rel="stylesheet" type="text/css" href="css/ajaxlivesearch.min.css">
    <script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>
  <!--<script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script>-->
  <!-- Live Search Script -->
<script type="text/javascript" src="js/ajaxlivesearch.min.js"></script>


<!--<script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/37/6/intl/en_gb/common.js"></script><script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/37/6/intl/en_gb/util.js"></script></head>-->
<style>
    .fa{
        color:#c29958;
    }
    
</style>

</head>