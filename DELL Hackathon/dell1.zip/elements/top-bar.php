<?php
/**
 * Created by PhpStorm.
 * User: Anukkrit
 * Date: 07-07-2019
 * Summary-
 * API Used-
 * Limitations-
 */



// session_start();
include "admin/connection.php";
include "dbcontroller.php";

$db= new DBController();

$db->connectDB();
$cat=$db->runQuery("SELECT * FROM category");

// var_dump($db);
// exit();
?>

<style>
    .preloader {
   position: absolute;
   top: 0;
   left: 0;
   width: 100%;
   height: 100%;
   z-index: 9999;
   background-image: url('assets/img/pre.gif');
   background-repeat: no-repeat; 
   background-color: #FFF;
   background-position: center;
}
    
</style>
<div class="preloader"></div>
<div>
    
    
    
    
</div>

<script>
 
$(window).on('load',function() {
   $('.preloader').fadeOut('slow');
});
	

</script>
<!-- Start Header Area -->
    <header class="header-area header-wide">
        <!-- main header start -->
        <div class="main-header d-none d-lg-block">
            <!-- header top start -->
            
            <!-- header top end -->

            <!-- header middle area start -->
            <div class="header-main-area sticky">
                <div class="container">
                    <div class="row align-items-center position-relative">

                        <!-- start logo area -->
                        <div class="col-lg-2">
                            <div class="logo">
                                <a href="index.php">
                                    <img src="assets/img/logo/logo.png" alt="VimalSonsJewel" style="width: 115px;height: 100px;margin-left: 30px;">
                                </a>
                            </div>
                        </div>
                        <!-- start logo area -->

                        <!-- main menu area start -->
                        <div class="col-lg-9 position-static">
                            <div class="main-menu-area">
                                <div class="main-menu">
                                    <!-- main menu navbar start -->
                                    <nav class="desktop-menu">
                                        <ul>
                                        <?php
            
            foreach ($cat as $value)
            {
                echo "<li class='position-static'><a href=shop.php?catid=".$value['ctID'].">".$value['ctName']."<i class='fa fa-angle-down'></i></a>";
                echo "<ul class='megamenu dropdown'>";
                
                $relmcat=array(9563,9565,9567,9566);
                if (in_array($value['ctID'],$relmcat)){
                    $sub=$db->runQuery('SELECT * FROM relcategories WHERE mcid='.$value['ctID'].' ORDER by relcat DESC');
                    // var_dump($sub);
                    // exit();
                    foreach($sub as $subvalue){
                        
                        // $subvalue["relcat"]=(int)$subvalue["relcat"];
                        // var_dump($subvalue['relcat']);
                        //     exit();
                        if((9559 < $subvalue["relcat"]) && (9568 > $subvalue["relcat"])){
                            $rel=$db->runQuery('SELECT * FROM category WHERE ctID='.$subvalue['relcat']);
                            // var_dump($rel);
                            // exit();
                            echo "<li class='mega-title'><a href=shop.php?catid=".$rel[0]['ctID']."><span>".$rel[0]['ctName']."</span></a></li>";
                        }else{
                            $rel=$db->runQuery('SELECT * FROM subcategory WHERE id='.$subvalue['relcat']);
                            // var_dump($rel);
                            // exit();
                            echo "<li class='mega-title'><a href=shop.php?catid=".$rel[0]['id']."><span>".$rel[0]['cat']."</span></a></li>";
                            
                        }
                          
                        
                        
                    }
                    
                    echo "</ul>";
                    
                }else{
                
                $sub=$db->runQuery('SELECT * FROM subcategory WHERE mcid='.$value['ctID']);
               
               if(isset($sub)){
                foreach ($sub as $subvalue){
                    echo "<li class='mega-title'><a href=shop.php?subid=".$subvalue['id']."><span>".$subvalue['cat']."</span></a>";
                    $subsub=$db->runQuery('SELECT * FROM subsubcategory WHERE mcid='.$value['ctID'].' AND scid='.$subvalue['id']);
                    echo "<ul>";
                    if(isset($subsub)){
                    foreach ($subsub as $subsubvalue){
                        echo "<li><a href=shop.php?subsubid=".$subsubvalue['id'].">".$subsubvalue['cat']."</a></li>";
                    }
                    }
                    echo "</ul></li>";
                }
                
               }
                echo "</li></ul>";
                
                }
            }

            ?>    

                                        </ul>
                                    </nav>
                                    <!-- main menu navbar end -->
                                </div>
                            </div>
                        </div>
                        <!-- main menu area end -->

                        <!-- mini cart area start -->
                        <div class="col-lg-1">
                            <div class="header-right d-flex align-items-center justify-content-xl-between justify-content-lg-end">
                                <!--<div class="header-search-container">-->
                                <!--    <button class="search-trigger d-xl-none d-lg-block"><i class="pe-7s-search"></i></button>-->
                                <!--    <form class="header-search-box d-lg-none d-xl-block animated jackInTheBox">-->
                                <!--        <input type="text" placeholder="Search entire store hire" class="header-search-field">-->
                                <!--        <button class="header-search-btn"><i class="pe-7s-search"></i></button>-->
                                <!--    </form>-->
                                <!--</div>-->
                                <div class="header-configure-area">
                                    <ul class="nav justify-content-end">
                                        <!--<li class="user-hover">-->
                                        <!--    <a href="#">-->
                                        <!--        <i class="pe-7s-user"></i>-->
                                        <!--    </a>-->
                                        <!--    <ul class="dropdown-list">-->
                                        <!--        <li><a href="login-register.html">login</a></li>-->
                                        <!--        <li><a href="login-register.html">register</a></li>-->
                                        <!--        <li><a href="my-account.html">my account</a></li>-->
                                        <!--    </ul>-->
                                        <!--</li>-->
                                        <li>
                                            <a href="search.php">
                                                <i class="fa fa-search"></i>
                                                <!--<div class="notification">0</div>-->
                                            </a>
                                        </li>
                                        <li>
                                            <a href="cart.php" class="minicart-btn">
                                                <i class="pe-7s-shopbag"></i>
                                                <div class="notification cartno" id="cartno"><?php 
                                                if (!isset($_SESSION['totalitems']) || is_null($_SESSION['totalitems']))
                                                     echo 0;
                                                else 
                                                    echo $_SESSION['totalitems'];
                                                ;?></div>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- mini cart area end -->

                    </div>
                </div>
            </div>
            <!-- header middle area end -->
        </div>
        <!-- main header start -->

        <!-- mobile header start -->
        <!-- mobile header start -->
        <div class="mobile-header d-lg-none d-md-block sticky" style="
    padding-top: 0px;
">
            <!--mobile header top start -->
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-12">
                        <div class="mobile-main-header">
                            <div class="mobile-logo">
                                <a href="index.php">
                                    <img src="assets/img/logo/logo.png" alt="Brand Logo">
                                </a>
                            </div>
                            <div class="mobile-menu-toggler">
                                <div class="mini-cart-wrap">
                                    <a href="cart.php">
                                        <i class="pe-7s-shopbag"></i>
                                        <div class="notification cartno"><?php 
                                                if (!isset($_SESSION['totalitems']) || is_null($_SESSION['totalitems']))
                                                     echo 0;
                                                else 
                                                    echo $_SESSION['totalitems'];
                                                ;?></div>
                                    </a>
                                </div>
                                <button class="mobile-menu-btn">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- mobile header top start -->
        </div>
        <!-- mobile header end -->
        <!-- mobile header end -->

        <!-- offcanvas mobile menu start -->
        <!-- off-canvas menu start -->
        <aside class="off-canvas-wrapper">
            <div class="off-canvas-overlay"></div>
            <div class="off-canvas-inner-content">
                <div class="btn-close-off-canvas">
                    <i class="pe-7s-close"></i>
                </div>

                <div class="off-canvas-inner">
                    <!-- search box start -->
                    <!--<div class="search-box-offcanvas">-->
                    <!--    <form>-->
                    <!--        <input type="text" placeholder="Search Here...">-->
                    <!--        <button class="search-btn"><i class="pe-7s-search"></i></button>-->
                    <!--    </form>-->
                    <!--</div>-->
                    <!-- search box end -->

                    <!-- mobile menu start -->
                    <div class="mobile-navigation">

                        <!-- mobile menu navigation start -->
                        <nav>
                            <ul class="mobile-menu">
                                
                                 <?php
            
            foreach ($cat as $value)
            {
                echo "<li class='menu-item-has-children'><span class='menu-expand'><i></i></span><a href=shop.php?catid=".$value['ctID'].">".$value['ctName']."</a>";
                echo "<ul class='dropdown'>";
                
                
                $relmcat=array(9563,9565,9567,9566);
                if (in_array($value['ctID'],$relmcat)){
                    $sub=$db->runQuery('SELECT * FROM relcategories WHERE mcid='.$value['ctID'].' ORDER by relcat DESC');
                    // var_dump($sub);
                    // exit();
                    foreach($sub as $subvalue){
                        
                        // $subvalue["relcat"]=(int)$subvalue["relcat"];
                        // var_dump($subvalue['relcat']);
                        //     exit();
                        if((9559 < $subvalue["relcat"]) && (9568 > $subvalue["relcat"])){
                            $rel=$db->runQuery('SELECT * FROM category WHERE ctID='.$subvalue['relcat']);
                            // var_dump($rel);
                            // exit();
                            echo "<li><a href=shop.php?catid=".$rel[0]['ctID'].">".$rel[0]['ctName']."</a></li>";
                        }else{
                            $rel=$db->runQuery('SELECT * FROM subcategory WHERE id='.$subvalue['relcat']);
                            // var_dump($rel);
                            // exit();
                            echo "<li><a href=shop.php?catid=".$rel[0]['id'].">".$rel[0]['cat']."</a></li>";
                            
                        }
                          
                        
                        
                    }
                    
                    echo "</ul>";
                    
                }else{
                
                $sub=$db->runQuery('SELECT * FROM subcategory WHERE mcid='.$value['ctID']);
               
               if(isset($sub)){
                foreach ($sub as $subvalue){
                    echo "<li ><a href=shop.php?subid=".$subvalue['id'].">".$subvalue['cat']."</a>";
                    $subsub=$db->runQuery('SELECT * FROM subsubcategory WHERE mcid='.$value['ctID'].' AND scid='.$subvalue['id']);
                    echo "<ul>";
                    if(isset($subsub)){
                    foreach ($subsub as $subsubvalue){
                        echo "<li><a href=shop.php?subsubid=".$subsubvalue['id'].">".$subsubvalue['cat']."</a></li>";
                    }
                    }
                    echo "</ul></li>";
                }
                
               }
                echo "</li></ul>";
            }
            }

            ?>
                               
                            </ul>
                        </nav>
                        <!-- mobile menu navigation end -->
                    </div>
                    <!-- mobile menu end -->

                    

                    <!-- offcanvas widget area start -->
                    <div class="offcanvas-widget-area">
                        <div class="off-canvas-contact-widget">
                            <ul>
                                <!--<li><i class="fa fa-mobile"></i>-->
                                <!--    <a href="Tel:022 49243132">022 49243132</a>-->
                                <!--</li>-->
                                <li><i class="fa fa-envelope-o"></i>
                                    <a href="mailto:contactus@vimalsonsjewel.com"> contactus@vimalsonsjewel.com</a>
                                </li>
                            </ul>
                        </div>
                        
                    </div>
                    <!-- offcanvas widget area end -->
                </div>
            </div>
        </aside>
        <!-- off-canvas menu end -->
        <!-- offcanvas mobile menu end -->
    </header>
    <!-- end Header Area -->