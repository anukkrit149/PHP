<!DOCTYPE html>
<html>
<?php include('elements/header.php'); ?>
<body>
    <?php include('elements/top-bar.php'); ?>
    
    <?php include('elements/cat-bar.php'); ?>
    
    <section id="main">
        <div class="container_12">
            <div id="content" class="grid_12">
                <header>
                    <h1 class="page_title">Item Name</h1>
                </header>
            
                    <div class="soc">
                        <a class="google" href="#"></a>
                        <a class="twitter" href="#"></a>
                        <a class="facebook" href="#"></a>
                    </div><!-- .soc -->
            
                <article class="product_page negative-grid">
                    <div class="grid_5 img_slid" id="products">
			<!--<img class="sale" src="img/sale.png" alt="Sale">-->
			<div class="preview slides_container">
			    <div class="prev_bg">
				<a href="img/content/product1.png" class="jqzoom" rel='gal1' title="">
				    <img src="img/content/product1.png" alt="Product 1" title="" style="width: 100%">
				</a>
			    </div>
			</div><!-- .preview -->
                        
                        <div class="next_prev">
			    <a id="img_prev" class="arows" href="#"><span>Prev</span></a>
			    <a id="img_next" class="arows" href="#"><span>Next</span></a>
			</div><!-- .next_prev -->

			<ul class="small_img clearfix" id="thumblist">
			    <li><a class="zoomThumbActive" href='javascript:void(0);' rel="{gallery: 'gal1', smallimage: './img/content/product1.png',largeimage: './img/content/product1.png'}"><img src='img/content/product1.png' alt=""></a></li>
			    <li><a href='javascript:void(0);' rel="{gallery: 'gal1', smallimage: './img/content/product2.png',largeimage: './img/content/product2.png'}"><img src='img/content/product2.png' alt=""></a></li>
			    <li><a href='javascript:void(0);' rel="{gallery: 'gal1', smallimage: './img/content/product3.png',largeimage: './img/content/product3.png'}"><img src='img/content/product3.png' alt=""></a></li>
			    <li><a href='javascript:void(0);' rel="{gallery: 'gal1', smallimage: './img/content/product4.png',largeimage: './img/content/product4.png'}"><img src='img/content/product4.png' alt=""></a></li>
			    <li><a href='javascript:void(0);' rel="{gallery: 'gal1', smallimage: './img/content/product5.png',largeimage: './img/content/product5.png'}"><img src='img/content/product5.png' alt=""></a></li>
			</ul><!-- .small_img -->

			<div id="pagination" style="margin-bottom: 20px;"></div>
		    </div><!-- .grid_5 -->
                    
                    <div class="grid_7">
			<div class="entry_content">
                
                           <div class="ava_price">
                                <div class="price" style="width: 350px;">
                                    <!--<div class="price_old">$1,725.00</div>-->
                                    &#8377 1,550.00 Approx</div>
				<div class="cart" style="margin-bottom:30px;float:right;">
                                <a href="#" class="bay"><img src="img/bg_cart.png" alt="Buy" title="">Add to Cart</a>
                                <a href="#" class="bay"><img src="img/bg_cart.png" alt="Buy" title="">Call</a>
                                <a href="#" class="bay"><img src="img/bg_cart.png" alt="Buy" title="">Whatsapp</a>
                                <!--<a href="#" class="compare"><span></span>Add to Compare</a>-->
                            </div><!-- .cart -->
				</div>
				
				
			    
                <?php include('elements/attribute-table.php'); ?>
                            
<!--<table class="tg">-->
<!--  <tr>-->
<!--    <th class="tg-0lax"></th>-->
<!--  </tr>-->
<!--</table>-->



			</div>
			<!-- .entry_content -->
		    </div>
		    <!-- .grid_7 -->
		    <div class="clear"></div>
                    
                    <div class="grid_12" >
			<div class="clear"></div>
		    </div><!-- .grid_12 -->
                    <div class="clear"></div>
		</article><!-- .product_page -->
                
               <?php include('elements/related-items.php'); ?>
                    
                <div class="clear"></div>
            </div><!-- #content -->

            <div class="clear"></div>
        </div><!-- .container_12 -->
    </section><!-- #main -->
    <div class="clear"></div>
    
    <?php include('elements/footer.php'); ?>

</body>


</html>
