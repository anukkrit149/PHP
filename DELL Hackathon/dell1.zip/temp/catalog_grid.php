<!DOCTYPE html>
<html>

<?php include('elements/header.php'); ?>
<body>
    <?php include('elements/top-bar.php'); ?>
    <?php include('elements/cat-bar.php'); ?>
    
    <section id="main">
        <div class="container_12">
            <div id="content" class="grid_9">
                <h1 class="page_title">Product List</h1>
                 
                <!-- .options -->
                <div class="clear"></div>
                
                <div class="products catalog negative-grid">
                   <?php
                   $i=6;
                   while($i)
                   {
                       echo "<article class='grid_3 article'>
                        <div class='prev'>
                            <a href='product_page.php'><img src='img/content/product1.png' alt='Product 1' title=''></a>
                        </div><!-- .prev -->
                        
                        <h3 class='title'>DEMO Emerald Cut<br> DEMO Emerald Ring</h3>
                        <div class='cart'>
                            <div class='price'>
                                <div class='vert'>
                                    DESC
                                    <div class='price_old'></div>
                                </div>
                            </div>".
                            // <a href='#' class='compare'></a>
                            // <a href='#' class='wishlist'></a>
                            "<a href='#' class='bay'><img src='img/bg_cart.png' alt='Buy' title=''></a>
                        </div><!-- .cart -->
                    </article><!-- .grid_3.article -->";
                       
                      $i-=1; 
                   }
                    ?>
                    
                    
                    
                    <div class="clear"></div>
                </div><!-- .products -->
                <div class="clear"></div>
	      
                <div class="pagination">
		    <ul>
			<li class="prev"><span>&#8592;</span></li>
			<li class="curent"><a href="#">1</a></li>
			<li><a href="#">2</a></li>
			<li><a href="#">3</a></li>
			<li><a href="#">4</a></li>
			<li><a href="#">5</a></li>
			<li><span>...</span></li>
			<li><a href="#">100</a></li>
			<li class="next"><a href="#">&#8594;</a></li>
		    </ul>
                </div><!-- .pagination -->
                <p class="pagination_info">Displaying 1 to 12 (of 100 products)</p>
                
                <div class="clear"></div>
            </div><!-- #content -->
            
            <div id="sidebar" class="grid_3">
                <aside id="categories_nav">
		    <header class="aside_title">
                        <h3>Categories</h3>
                    </header>

		    <nav class="right_menu">
			<ul>
			    <li><a href="#">Home</a></li>
			    <li><a href="#">Wedding</a></li>
			    <li class="current"><a href="#">Rings</a></li>
			    <li><a href="#">Necklaces</a></li>
			    <li><a href="#">Earrings</a></li>
			    <li><a href="#">Bracelets</a></li>
			</ul>
		    </nav><!-- .right_menu -->
                </aside><!-- #categories_nav -->
                
                
            </div><!-- .sidebar -->
            <div class="clear"></div>
        </div><!-- .container_12 -->
    </section><!-- #main -->
    <div class="clear"></div>
    <?php include('elements/footer.php'); ?>
</body>


</html>
