<!doctype html>
<html class="no-js" lang="en">


<?php include('elements/header.php'); ?>

<body>
    
    <?php include('elements/top-bar.php'); 
    
$category=$db->runQuery("SELECT * FROM category");    
$slider=$db->runQuery("SELECT * FROM slider");

$tt=json_encode($slider);

echo "<script>console.log(".$tt.")</script>";

    
    ?>


    <main>
        <!-- hero slider area start -->
        <section class="slider-area">
            <div class="hero-slider-active slick-arrow-style slick-arrow-style_hero slick-dot-style">
                <!-- single slider item start -->
                <div class="hero-single-slide hero-overlay">
                    <div class="hero-slider-item bg-img" data-bg="<?php echo $slider[0]['path']?>">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="hero-slider-content slide-1">
                                        <h2 class="slide-title"><?php echo $slider[0]['title']?> <span>Collection</span></h2>
                                        <h4 class="slide-desc"><?php echo $slider[0]['content']?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single slider item start -->

                <!-- single slider item start -->
                <div class="hero-single-slide hero-overlay">
                    <div class="hero-slider-item bg-img" data-bg="<?php echo $slider[1]['path']?>">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="hero-slider-content slide-2 float-md-right float-none">
                                        <h2 class="slide-title"><?php echo $slider[1]['title']?><span>Collection</span></h2>
                                        <h4 class="slide-desc"><?php echo $slider[1]['content']?></h4>
                                        <!--<a href="shop.html" class="btn btn-hero">Read More</a>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single slider item start -->

                <!-- single slider item start -->
                <div class="hero-single-slide hero-overlay">
                    <div class="hero-slider-item bg-img" data-bg="<?php echo $slider[2]['path']?>">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="hero-slider-content slide-3">
                                        <h2 class="slide-title"><?php echo $slider[2]['title']?><span>Jewellery</span></h2>
                                        <h4 class="slide-desc"><?php echo $slider[2]['content']?></h4>
                                        <!--<a href="shop.html" class="btn btn-hero">Read More</a>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single slider item end -->
            </div>
        </section>
        <!-- hero slider area end -->

        
        <!-- product banner statistics area start -->
        <section class="product-banner-statistics section-padding">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="section-title text-center">
                            <h2 class="title">Categories</h2>
                            <p class="sub-title">Choose your Category</p>
                        </div>
                        
                        <div class="product-banner-carousel slick-row-10">
                        
                        <?php 
                        $i=0;
                        while(true){
    if(empty($category[$i]))
        break;
    // $pic_rows=$db->runQuery('SELECT * FROM itempic WHERE itID='.$category[$i]['itID']);
    echo "<div class=\"banner-slide-item\">
                                <figure class=\"banner-statistics\">
                                    <a href=shop.php?catid=".$category[$i]['ctID'].">
                                        <img src=".$category[$i]['img']." alt=\"product banner\">
                                    </a>
                                    <div class=\"banner-content banner-content_style2\">
                                        <h5 class=\"banner-text3\"><a href=shop.php?catid=".$category[$i]['ctID'].">".$category[$i]['ctName']."</a></h5>
                                    </div>
                                </figure>
                            </div>";
    $i++;

}
                        
                        ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    

        <?php include 'featuredpdts.php';?>

    
        <section class="testimonial-area section-padding bg-img" data-bg="assets/img/testimonial/testimonials-bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <!-- section title start -->
                        <div class="section-title text-center">
                            <h2 class="title">About Us</h2>
                            <!--<p class="sub-title">What they say</p>-->
                        </div>
                        <!-- section title start -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <!--<div class="testimonial-thumb-wrapper">-->
                        <!--    <div class="testimonial-thumb-carousel">-->
                        <!--        <div class="testimonial-thumb">-->
                        <!--            <img src="assets/img/testimonial/testimonial-1.png" alt="testimonial-thumb">-->
                        <!--        </div>-->
                        <!--        <div class="testimonial-thumb">-->
                        <!--            <img src="assets/img/testimonial/testimonial-2.png" alt="testimonial-thumb">-->
                        <!--        </div>-->
                        <!--        <div class="testimonial-thumb">-->
                        <!--            <img src="assets/img/testimonial/testimonial-3.png" alt="testimonial-thumb">-->
                        <!--        </div>-->
                        <!--        <div class="testimonial-thumb">-->
                        <!--            <img src="assets/img/testimonial/testimonial-2.png" alt="testimonial-thumb">-->
                        <!--        </div>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="testimonial-content-wrapper">
                            <div class="testimonial-content-carousel">
                                <div class="testimonial-content">
                                    <p>Vimalsons Jewel , a leading establishment in Mumbai in the category of corporate Gift Manufacturers, has its roots in the jewelry industry dating back over 20 years.
What has remained constant is the company’s philosophy of providing the highest possible level of service and quality products. When it comes to manufacturing beautifully carved Silver Products, we have made offers in event gifting, corporate gifting and online sales. We offer a vast range of certified products in diverse style. From traditional, international, classic and casual we have innovative products that are sure to make people happy. All our products have certification and credibility. Our extensive collection of different products combines fine craftsmanship with all the latest designs whilst maintaining the highest standards of quality and value for money. We are fully committed to ensuring that all the items supplied by us are conflict-free and have the necessary guarantees and assurances. 
We have designers to design products according to the customer’s requirements. We pack our products safely to avoid any damage from our side.
</p>
                                    <!--<div class="ratings">-->
                                    <!--    <span><i class="fa fa-star-o"></i></span>-->
                                    <!--    <span><i class="fa fa-star-o"></i></span>-->
                                    <!--    <span><i class="fa fa-star-o"></i></span>-->
                                    <!--    <span><i class="fa fa-star-o"></i></span>-->
                                    <!--    <span><i class="fa fa-star-o"></i></span>-->
                                    <!--</div>-->
                                    <!--<h5 class="testimonial-author">lindsy niloms</h5>-->
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- testimonial area end -->

    </main>

    <!-- Scroll to top start -->
    <div class="scroll-top not-visible">
        <i class="fa fa-angle-up"></i>
    </div>
    <!-- Scroll to Top End -->

    <?php include('elements/footer.php'); ?>
    
    
    
</body>

</html>