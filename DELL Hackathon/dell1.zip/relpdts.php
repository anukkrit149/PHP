<?php
/**
 * Created by PhpStorm.
 * User: Anukkrit
 * Date: 25-07-2019
 * Summary-
 * API Used-
 * Limitations-
 */
// var_dump($db);
// exit();
// include "dbcontroller.php";
// $db= new DBController();

// $db->connectDB();

// var_dump($db);
// exit();

$i=0;

//var_dump($row_f);

while(true){
    if(!isset($row_f[$i]))
        break;
    $pic = $pdo->query('SELECT * FROM itempic WHERE itID='.$row_f[$i]['itID']);
    $pic_rows = $pic->fetchAll();
    echo "<div class='product-item'>
                                    <figure class='product-thumb'>
                                        <a href='product-details.php?pid=".$row_f[$i]['itID']."'>
                                            <img class='pri-img' src='admin/".$pic_rows[0]['path']."' alt='product'>
                                            <img class='sec-img' src='admin/".$pic_rows[0]['path']."' alt='product'>
                                        </a>
               
                                    </figure>
                                    <div class='product-caption text-center'>
                                        <div class='product-identity'>
                                            <p class='manufacturer-name'><a href='product-details.php?pid=".$row_f[$i]['itID']."'>Vimalsons</a></p>
                                        </div>
                                        <h6 class='product-name'>
                                            <a href='product-details.php?pid=".$row_f[$i]['itID']."'>".$row_f[$i]['itName']."</a>
                                        </h6>
                                        <div class='price-box'>
                                            <span class='price-regular'>&#x20b9 ".$row_f[$i]['itPrice']." Approx</span>
                                        </div>
                                    </div>
                                </div>";
    $i++;

}


?>




