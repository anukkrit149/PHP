
<!doctype html>
<html class="no-js" lang="zxx">

<?php include ('elements/header.php'); ?>

<body>

<?php include ('elements/top-bar.php'); ?>

<main>
    <!-- breadcrumb area start -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb-wrap">
                        <nav aria-label="breadcrumb">
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home"></i></a></li>
                                <li class="breadcrumb-item">Shop</li>
                                <li class="breadcrumb-item active" aria-current="page">cart</li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumb area end -->

    <!-- cart main wrapper start -->
    <div class="cart-main-wrapper section-padding">
        <div class="container">
            <div class="section-bg-color">
                <div class="row">
                    <div class="col-lg-12">
                        <!-- Cart Table Area -->
                        <div class="cart-table table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                    <th class="pro-thumbnail">Thumbnail</th>
                                    <th class="pro-title">Product</th>
                                    <th class="pro-price">Quantity</th>
                                    <th class="pro-quantity">Price</th>
                                    <!--<th class="pro-remove">Remove</th>-->
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                /**
                                 * Created by PhpStorm.
                                 * User: Anukkrit
                                 * Date: 24-07-2019
                                 * Summary-
                                 * API Used-
                                 * Limitations-
                                 */
                                foreach ($_SESSION["cart_item"] as $key => $value)
                                {
                                    if (!empty($value['name'])){
                                    $pic_rows=$db->runQuery('SELECT * FROM itempic WHERE itID='.$value['id']);
                                    // var_dump($pic_rows);
                                    // exit();
                                    echo "<tr class='item'>
                                    <td class=\"pro-thumbnail\"><a href=product-details.php?pid=".$value['id']."><img class=\"img-fluid\" src='admin/".$pic_rows[0]['path']."' alt=\"Product\" /></a></td>
                                    <td class=\"pro-title\"><a href=product-details.php?pid=".$value['id'].">".$value['name']."</a></td>
                                    <td class=\"pro-quantity\">
                                        <div class='pro-qty'><input type='text' value='1'></div>
                                    </td>
                                    <td class=\"pro-price\">&#x20b9<span>".$value['price']."</span></td>
                                    
                                    
                                </tr>";}
                                

                                }


                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3 ml-auto">
                        <div class="cart-calculator-wrapper">
                            <div class="cart-calculate-items" style="text-align: center;">
                        <a href='#' class=' btn btn-cart rmit' style="
    color: black;
    background: #c29958;
    border-radius: 10px;
    font-size: 20px;
">&nbsp &nbsp Empty Cart &nbsp &nbsp<i class=\"fa fa-trash-o\"></i></a>
                        </div>
                        </div>
                    </div>
                    <div class="col-lg-9 ml-auto">
                        <!-- Cart Calculation Area -->
                        <div class="cart-calculator-wrapper">
                            <div class="cart-calculate-items">
                                <h6>Cart Totals</h6>
                                <div class="table-responsive">
                                    <table class="table">
                                        <tr class="total">
                                            <td>Total Items</td>
                                            <td class="total-amount"> <?php if (!isset($_SESSION['totalitems']) || is_null($_SESSION['totalitems']))
                                                     echo 0;
                                                else 
                                                    echo $_SESSION['totalitems'];?> items</td>
                                                    </tr><tr>
                                            <td>Total</td>
                                            <td class="total-amount">&#x20b9 <?php if (!isset($_SESSION['totalprice']) || is_null($_SESSION['totalprice']))
                                                     echo 0;
                                                else 
                                                    echo $_SESSION['totalprice'];?> Approx</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <a href="#" class="btn btn-sqr d-block" data-toggle="modal" data-target="#largeModal">Proceed Enquire</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- cart main wrapper end -->
</main>
<script>
    // $(document).ready(
        
    //     var price = parseInt($('td.pro-price').text())
    //     $.each(price,function(){
            
    //         console.log(price);
    //     })
        
        
    //     )
    
    $(".rmit").on('click',function(){
        $.ajax({
                type: 'POST',
                url: 'cartAjax.php',
                data: {
                    action:"empty",
                    // pid:parseInt($('#pid').text()),
                    // cartitems:parseInt($('#cartno').text())
                },
                success: function (data) {
                    // window.location.href="https://vimalsonsjewel.com/cart.php";
                    console.log(data);
                    data=JSON.parse(data);
                    console.log(data);
                    console.log($('#pid').text());
                    var value=parseInt($('#cartno').text())
                    // console.log(
                        // value+=1
                        // );
                    $('#cartno').text(value)
                    // =value.toString();
                     location.reload(true);
                    
                }
        })
        
        
    })
    
    
    
    
</script>


<!-- Scroll to top start -->
<div class="scroll-top not-visible">
    <i class="fa fa-angle-up"></i>
</div>
<!-- Scroll to Top End -->
<?php include ('elements/footer.php'); ?>
<style>
    .fa{
        color:#c29958;
    }

</style>
<!-- Quick view modal start -->

<div class="modal fade" id="largeModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Enquire </h4></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-3 ml-auto">
                        <a id='wht' href="#"><i class="fa fa-whatsapp fa-5x"></i>
                            <h3>Whatsapp</h3>
                    </div></a>

                    <div class="col-lg-3 ml-auto">
                        <a href="tel:02249243132"> <i class="fa fa-phone fa-5x"></i>
                            <h3>Phone</h3>
                    </div></a>
                    <div class="col-lg-3 ml-auto">
                        <a href="#" id="mail"> <i class="fa fa-envelope fa-5x"></i>
                            <h3>Email</h3>
                    </div></a>

                </div>


            </div>
            <div class="modal-footer">
                <div class="row">
                    <!--<h3>VimalSons</h3>-->

                </div>

                <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
                <!--<button type="button" class="btn btn-primary">Save changes</button>-->
            </div>
        </div>
    </div>
</div>
<script>

$(document).ready(
    function()
    {
        console.log($('.cart-table').text());
        
        $(document).on('click','#wht',function(){
           console.log($('.cart-table').text());
           var Url=" https://api.whatsapp.com/send?phone=919321783031&text="+encodeURI('Hey,I want to enquire about some products listed below-');
           var ctr=1;
           $('tr.item').each(function (index, value){
                $.each(this.cells, function(index, value){
                    var val = $(value).html();
                    if (index==2){
                        val=$('input').val()
                    }else if(index==0){
                        val="";
                    }else{
                        val=$(value).text();
                    }
                    
                             Url+=encodeURI("-"+val);
                             Url+=encodeURI("\n");
                           });
           });
            Url+=encodeURI($('tr.total').text());       
                           
          window.location.href = Url;
           
            
        });
        
        $(document).on('click','#mail',function(){
           
           var Url="mailto:contactus@vimalsonsjewel.com?Subject=Order&body="+encodeURI('Hey,I want to enquire about some products listed below-');
           var ctr=1;
           $('tr.item').each(function (index, value){
               
                             Url+=encodeURI(ctr+". "+$(value).text());
                            //  Url+=encodeURI("\n");
                           });
            Url+=encodeURI($('tr.total').text());       
                           
          window.location.href = Url;
           
            
        });
        
    });
    


    
    
    
    
</script>
<!-- Quick view modal end -->
</body>



</html>
